﻿//ID: 1784319
//lab 1
//due: 2/7/2018
//CIS 200-01
// answers questions from the book


using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Lab1
{
    public class LinqTest
    {
        public static void Main(string[] args)
        {
            // initialize array of invoices
            Invoice[] invoices = { 
                new Invoice( 83, "Electric sander", 7, 57.98M ), 
                new Invoice( 24, "Power saw", 18, 99.99M ), 
                new Invoice( 7, "Sledge hammer", 11, 21.5M ), 
                new Invoice( 77, "Hammer", 76, 11.99M ), 
                new Invoice( 39, "Lawn mower", 3, 79.5M ), 
                new Invoice( 68, "Screwdriver", 106, 6.99M ), 
                new Invoice( 56, "Jig saw", 21, 11M ), 
                new Invoice( 3, "Wrench", 34, 7.5M ) };

            // Display original array
            Console.WriteLine("Original Invoice Data\n");
            Console.WriteLine("P.Num Part Description     Quant Price"); // Column Headers
            Console.WriteLine("------------------------------------Unsorted------------------------------------");

            foreach (Invoice inv in invoices)
                Console.WriteLine(inv);
            
            Console.WriteLine("----------------------------sort by Part Description----------------------------"); //seporator

            //Sorts invoices by part description
            var sortByPartDescription =
                from inv in invoices
                orderby inv.PartDescription
                select inv;
            
            //prints off list ordered by part description
            foreach (var element in sortByPartDescription)
                Console.WriteLine($"{element}");

            Console.WriteLine("---------------------------------sort by Price---------------------------------"); //seporator

            //sorts by price
            var sortByPrice =
                from money in invoices
                orderby money.Price
                select money;

            //prints off list ordered by price
            foreach (var element in sortByPrice)
                Console.WriteLine($"{element}");

            Console.WriteLine("------------------------------------Quantity------------------------------------"); //seporator

            //sorts by quantity
            var sortByQuantity =
                from Quan in invoices
                orderby Quan.Quantity
                select new { Quan.PartDescription, Quan.Quantity } ;

            //prints off list ordered by quantity
            foreach (var element in sortByQuantity)
                Console.WriteLine($"{element.PartDescription,-20} {element.Quantity}");

            Console.WriteLine("------------------------------------Invoice------------------------------------"); //seporator
            
            // finds total for each item, orders by money
            var total =
                from invtotal in invoices
                let inv = invtotal.Quantity * invtotal.Price
                orderby inv
                select new { invtotal.PartDescription, inv};
           
            //prints off total list
            foreach (var element in total)
                Console.WriteLine($"{element.PartDescription,-20} {element.inv}");

            Console.WriteLine("------------------------------------Invoice between $200 and $500------------------------------------");//seporator

            //fints total for each item, orders by money, only uses money between 200 and 500
            var totallimit =
              from invtotal in invoices
              let inv = invtotal.Quantity * invtotal.Price
              where inv <=500 && inv >=200
              orderby inv
              select new { invtotal.PartDescription, inv };

            //prints off total with limit
            foreach (var element in totallimit)
                Console.WriteLine($"{element.PartDescription,-20} {element.inv}");
        }
    }
}
